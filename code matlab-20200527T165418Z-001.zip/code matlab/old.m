N=100;  % no of sensors
M=50;   % no of locations
T=800;    %total time taken
Time=T;
x=randi([0,100],1,N); % x co-ordinate of sensors
y=randi([0,100],1,N); % y co-ordinate of sensors
a=randi([0,100],1,M); %  x co-ordinate of locations
b=randi([0,100],1,M); %  y co-ordinate of locations
plot(x,y,'+',a,b,'O');
Rm=30;                  % radius of sink
speed=2;                 % speed of sink
E=randi([10,30],1,N);   % initial energy stored in sensors
Ns=zeros(M,N); % matrix for adding neighbour sensors of each location
ec=0.6 ;          % energy consumption in transmitting data per unit length
gv=1;            % data transmission or generation rate of sensors
totaldata=T*N*gv;
mobiledata=0;
eh=0.7;          % energy harvested per sec
cv=1000 ;          % capacity of sensors
index=1;
tij=0;
tj=0;
ti0=0;
trajectory=zeros(1,M); % array to add loaction in trajectory
traj=1; % variable for trajectory array
while(T>0)
    
    feasible_loc=zeros(1,M); % array for feasible loactions each time
    
    max_data=zeros(1,M);  %max data of each location
    sojourn_t=zeros(1,M); % sojourn time of each location
    
    for i=1:M
        
        k=1;
        for j=1:N
            if(((x(j)-a(i))^2 +(y(j)- b(i))^2)<=Rm^2)
                Ns(i,k)=j;
                k=k+1;
            end
            
        end
        
        
        if(k>1)
            k=k-1;
            survival_t=zeros(1,k); % survival time of neighbouring sensors for each location
            
            for p=1:k
                %l=sqrt((a(i)-x(Ns(i,p)))^2+(b(i)-y(Ns(i,p)))^2);
                survival_t(1,p)=E(1,Ns(i,p))/ec*gv;
                
            end
            
            
            
            sort(survival_t,'descend');
            data=zeros(1,k);
            for p=1:k
                data(1,p)=p*survival_t(1,p)*gv;       %adding data for each survival time of sensors
                
                
            end
            %disp(data)
            
            
            
            
            
            max=data(1,1);
            index=1;
            for p=1:k
                if(data(1,p)>max)
                    max=data(1,p);
                    index=p;
                    
                end
            end
            
            max_data(1,i)=max;
            sojourn_t(1,i)=survival_t(1,index);
            
            
            %disp(max_data);
            %disp(sojourn_t);
            f=1;
            if(traj>1)
                f=trajectory(1,traj-1);
            end
            tij=(sqrt((a(f)-a(i))^2+(b(f)-b(i))^2))/speed;
            
            tj0=(sqrt((a(i)-a(1))^2+(b(i)-b(1))^2))/speed;
            dtj=T-tj0-tij;
            
            if(sojourn_t(1,i)>dtj)                        %condition for last location
                p=index+1;
                while(p<=k&&survival_t(1,p)>dtj)
                    p=p+1;
                end
                max=index*dtj*gv;
                tj=dtj;
                if(p<=k)
                    
                    for j=p:k
                        max1=j*survival_t(1,j)*gv;
                        
                        if(max1>max)
                            max=max1;
                            tj=survival_t(1,j);
                        end
                    end
                end
                
                sojourn_t(1,i)=tj;
                
                max_data(1,i)=max;
            end
        end
    end                         % this is the end of for loop of each location calculation
    
    
    
    
    if(traj==1)
        %if(sojourn_t(1,1)<=T)     % as sink starts from first loc so the case of havig no neighbours is also handled here as soj time will be 0 if no neighbours
        T=T-sojourn_t(1,1);
        
        %else
        %T=0;
        
        
        trajectory(1,traj)=1;
        traj=traj+1;
        
        index=1;
        
        
        
    else
        loc=1;                %variable for adding feasible locations in feasible_loc array
        for i=1:M
            
            tj=sojourn_t(1,i);
            f=1;
            if(traj>1)
                f=trajectory(1,traj-1);
            end
            tij=(sqrt((a(f)-a(i))^2+(b(f)-b(i))^2))/speed;
            tj0=(sqrt((a(i)-a(1))^2+(b(i)-b(1))^2))/speed;
            
            if(tj~=0&&tj+tij+tj0<=T)           %might be there are no neighbours so tj will be zero in that case so it must not be feasible
                feasible_loc(1,loc)=i;
                loc=loc+1;
            end
        end
        
        
        
        if(loc>1)
            loc=loc-1;
            %end
            ratio=zeros(1,loc);
            for j=1:loc
                
                tj=sojourn_t(1,feasible_loc(1,j));
                f=1;
                if(traj>1)
                    f=trajectory(traj-1);
                end
                ti0=(sqrt((a(f)-a(1))^2+(b(f)-b(1))^2))/speed;            %time to return from prev to zero location
                tij=(sqrt((a(f)-a(feasible_loc(1,j)))^2+(b(f)-b(feasible_loc(1,j)))^2))/speed;
                tj0=(sqrt((a(feasible_loc(1,j))-a(1))^2+(b(feasible_loc(1,j))-b(1))^2))/speed;
                ratio_time=tij+tj+tj0-ti0;
                ratio(1,j)=max_data(1,feasible_loc(1,j))/ratio_time;
            end
            
            
            max=ratio(1,1);
            index=1;
            for j=1:loc
                if(ratio(1,j)>max)
                    max=ratio(1,j);
                    index=j;
                end
            end
            trajectory(1,traj)=feasible_loc(1,index);
            traj=traj+1;
            tj=sojourn_t(1,feasible_loc(1,index));
            f=1;
            if(traj>1)
                f=trajectory(1,traj-1);
            end
            tij=(sqrt((a(f)-a(feasible_loc(1,index)))^2+(b(f)-b(feasible_loc(1,index)))^2))/speed;
            
            
            p=1;
            while(Ns(feasible_loc(1,index),p)>0)    %energy left after transmitting data by sensors
                E(1,Ns(feasible_loc(1,index),p))=E(1,Ns(feasible_loc(1,index),p))-ec*(tj+tij);
                p=p+1;
            end
            mobiledata=mobiledata+tj*p*gv;
            
            T=T-tij-tj;       %total time left
            %t0i=tij+tj;
            for j=1:N          % energy recharged by all sensors during each travelling and sojourn time
                E(1,j)=min(E(1,j)+eh*(tj+tij),cv);
            end
        end
    end
end
disp("T ="+Time+" "+"N ="+N+"   totaldata= "+totaldata+"   mobiledata= "+mobiledata+"   throughput= "+mobiledata/totaldata);
%disp(mobiledata/totaldata);


disp(trajectory);