function [sum]= find_sum(Cluster_head,Nodes)
    sum=0;
    for j=1:Nodes
        sum=sum+Cluster_head(j);
    end
end