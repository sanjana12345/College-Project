function [paths,visited,Temp_Energy,alert,x] = bfspaths(paths,visited,level,Temp_Energy,current,Graph,x,Data,sparseAdj,ec)
    x_m=x;
    level_nodes=graphtraverse(sparseAdj,current,'depth',level);
    %%prelevel_nodes=graphtraverse(sparseAdj,current,'depth',level-1);
    %%level_nodes=setdiff(level_nodes,prelevel_nodes);
    all=1;
    alert=0;
    for node = level_nodes
        if(Temp_Energy(current)-(ec*Data(node))>=0 && Temp_Energy(node)-(ec*Data(node))>=0 &&visited(1,node)==0)
            all=0;
        end
    end
    if(all==0)
        for node = level_nodes
            if(visited(1,node)==1)
                continue;
            end
            single_path=shortestpath(Graph,current,node);
            satisfy=1;
            for path_node = single_path
                if(Temp_Energy(path_node)-(ec*Data(node))<0 || (visited(2,path_node)~=current && visited(2,path_node)~=0) || (visited(1,path_node)==0 && path_node~=node))
                    satisfy=0;
                end
            end
            if(satisfy==1 && visited(1,node)==0)
                j=1;
                for path_node = single_path
                    %disp(current+" "+path_node+" "+node+" "+Temp_Energy(path_node)+" "+Data(node));
                    Temp_Energy(path_node)=Temp_Energy(path_node)-(ec*Data(node));
                    visited(1,path_node)=1;
                    visited(2,path_node)=current;
                    paths(x,j)=path_node;
                    j=j+1;
                end
                x=x+1;
            end
        end
    else
        alert=all;
    end
    if(x==x_m)
        alert=1;
    end
end