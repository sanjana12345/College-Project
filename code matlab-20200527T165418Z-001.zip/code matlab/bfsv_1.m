
Nodes=10;  %number of sensors
x_coordinate=randi([0 100],1,Nodes); %x position of sensors
y_coordinate=randi([0 100],1,Nodes); %y position of sensors
Data=randi([1000 1000],1,Nodes); %data stored of sensors
Energy=randi([5 15],1,Nodes); %total energy of sensors
Radius=40; % Radius of communication
Graph=graph(); % Network of nodes
%Included=ones(1,Nodes); %To check if each node is includes in any cluster or not. 0 indicates included in cluster. Initally each node is not inlcuded.
Cluster_head=zeros(1,Nodes); %If node is made a cluster head its hash is changed to 1.
Adj=zeros(Nodes,Nodes); %Adjancey Matrix
%Clusters=zeros(Nodes,Nodes);
Temp_Energy=Energy; %Temporary Energy Array
visited=zeros(2,Nodes); %Visited Array. Row 1 contains visited boolean value, Row 2 contains current path, Row 3 contains boolean dead end value
paths=zeros(Nodes,Nodes); %Various Paths DFS.
Distances=inf(Nodes,Nodes); %Distances between each node in terms of time taken for travelling
Transmission_Rate= 150; % Data Trasmission Rate
Speed = 2; % Mobile Sink Speed
Total_data = 0;
Time=0;
ec=150*(10^-9);

% Adding edges between nodes capable of communicating with each other or creating network
for i=1:Nodes
    for j=i+1:Nodes
        if (((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)<=Radius^2)
            Graph=addedge(Graph,i,j);
            Adj(i,j)=1;
            Adj(j,i)=1;
        end
        Distances(i,j)=sqrt((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)/Speed;
        Distances(j,i)=sqrt((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)/Speed;
    end
end

sparseAdj=sparse(Adj);

for i=1:Nodes
    Total_data= Total_data + Data(i);
end

plot(Graph);
% Distances=distances(Graph,'Method','unweighted'); %All Pair shortest path
Ratio=Energy./Data; %Ratio of Energy Array by Data Array
% Deg=degree(Graph); %Degree of all nodes
% Deg=Deg.'; %Transpose of Degree Matrix. Returns in same configuration as Ratio Matrix
[Sorted_Ratio,Sorted_Ratio_Indices]=sort(Ratio,'descend'); %Returns sorted cluster parameter and their indices

%Finding Cluster heads and corresponding clusters.
x=1;
for i=1:Nodes
    current=Sorted_Ratio_Indices(i);
    alert=0;
    level=1;
    if(visited(1,current)~=1)
        visited(1,current)=1;
        visited(2,current)=current;
        if(Temp_Energy(current)-(ec*Data(current))>=0)
            Temp_Energy(current)=Temp_Energy(current)-(ec*Data(current));
            while (alert==0)
                [paths,visited,Temp_Energy,alert,x] = bfspaths(paths,visited,level,Temp_Energy,current,Graph,x,Data,sparseAdj,ec); 
                level=level+1;
            end
        end
    end
    sum=0;
    for l=1:Nodes
        sum=sum+visited(1,l);
    end
    if(sum>=Nodes)
        break;
    end
end
