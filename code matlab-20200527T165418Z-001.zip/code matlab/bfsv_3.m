k=0;
ap=0;
while k<30
    
    Nodes=600;  %number of sensors
    x_coordinate=randi([0 100],1,Nodes); %x position of sensors
    y_coordinate=randi([0 100],1,Nodes); %y position of sensors
    Data=randi([1000 1000],1,Nodes); %data stored of sensors
    Energy=randi([5 15],1,Nodes); %total energy of sensors
    Radius=30; % Radius of communication
    Graph=graph(); % Network of nodes
    Adj=zeros(Nodes,Nodes); %Adjancey Matrix
    Distances=inf(Nodes,Nodes); %Distances between each node in terms of time taken for travelling
    Transmission_Rate= 10000; % Data Trasmission Rate
    Speed = 2; % Mobile Sink Speed
    Total_data = 1000*Nodes; % Total data offered by network
    t=800; % Time
    current_loc=1;
    eh=0.5*(10^-3); % Energy harvesting rate
    dg=1000; % Data generation rate
    ec=150*(10^-9); % Energy consumption per bit data
    data_collect=0; % Data collected
    
    % Adding edges between nodes capable of communicating with each other or creating network
    for i=1:Nodes
        for j=i+1:Nodes
            if (((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)<=Radius^2)
                Graph=addedge(Graph,i,j);
                Adj(i,j)=1;
                Adj(j,i)=1;
            end
            Distances(i,j)=sqrt((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)/Speed;
            Distances(j,i)=sqrt((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)/Speed;
        end
    end
    sparseAdj=sparse(Adj);
    
    while(t>0)
        
        visited=zeros(2,Nodes); %Visited Array. Row 1 contains visited boolean value, Row 2 contains current path, Row 3 contains boolean dead end value
        Cluster_head=zeros(1,Nodes); %If node is made a cluster head its hash is changed to 1.
        paths=zeros(Nodes,Nodes); %Various Paths BFS.
        Temp_Energy=Energy; %Temporary Energy Array
        Ratio=Energy./Data; %Ratio of Energy Array by Data Array
        [Sorted_Ratio,Sorted_Ratio_Indices]=sort(Ratio,'descend'); %Returns sorted cluster parameter and their indices
        include=zeros(1,Nodes);
        Temp_Data=Data; %Temporary Data Array
        rat=zeros(1,Nodes);
        %Finding Cluster heads and corresponding clusters.
        
        x=1;
        for i=1:Nodes
            current=Sorted_Ratio_Indices(i);
            alert=0;
            level=1;
            if(visited(1,current)~=1)
                visited(1,current)=1;
                visited(2,current)=current;
                if(Temp_Energy(current)-(ec*Data(current))>=0)
                    Temp_Energy(current)=Temp_Energy(current)-(ec*Data(current));
                    while (alert==0)
                        [paths,visited,Temp_Energy,alert,x] = bfspaths(paths,visited,level,Temp_Energy,current,Graph,x,Data,sparseAdj,ec);
                        level=level+1;
                    end
                end
            end
            sum=0;
            for l=1:Nodes
                sum=sum+visited(1,l);
            end
            if(sum>=Nodes)
                break;
            end
        end
        
        for i=1:Nodes
            for j=2:Nodes
                if(paths(i,j)==0)
                    break;
                elseif(include(paths(i,j))~=1)
                    Temp_Data(paths(i,1))=Temp_Data(paths(i,1))+Temp_Data(paths(i,j));
                    include(paths(i,j))=1;
                end
            end
        end
        
        %% To calculate total data present at a cluster head with its cluster and neighbour.
        head_data=Temp_Data;
        
        for i=1:Nodes
            if(Cluster_head(i)==0)
                for j=1:Nodes
                    if(Cluster_head(j)==0&&Adj(i,j)==1)
                        head_data(i)=head_data(i)+Temp_Data(j);
                    end
                end
            end
        end
        
        for i=1:Nodes
            rat(i)=head_data(i)/Distances(current_loc,i);
        end
        
        
        [max_rat,max_rat_ind]=sort(rat,'descend');
        
        td=Distances(current_loc,max_rat_ind(1))+head_data(max_rat_ind(1))/Transmission_Rate;
        
        if(t-td<0)
            break;
        end
        t=t-td;
        data_collect=data_collect+head_data(max_rat_ind(1));
        dta=td*dg;
        ener=td*eh;
        
        include=zeros(1,Nodes);
        
        %% Deducting energy from cluster head and its neigbours
        for i=1:Nodes
            if(paths(i,1)==max_rat_ind(1))
                for j=2:Nodes
                    if(paths(i,j)>0)
                        Energy(paths(i,j))=Energy(paths(i,j))-Temp_Energy(paths(i,j));
                        Data(paths(i,j))=0;
                    elseif(paths(i,j)==0)
                        break;
                    end
                end
            end
        end
        Data(max_rat_ind(1))=0;
        Energy(max_rat_ind(1))=Energy(max_rat_ind(1))-Temp_Energy(max_rat_ind(1));
        
        for m=1:Nodes
            if(Cluster_head(m)==0 && Adj(m,max_rat_ind(1))==1)
                for i=1:Nodes
                    if(paths(i,1)==m)
                        for j=2:Nodes
                            if(paths(i,j)>0)
                                Energy(paths(i,j))=Energy(paths(i,j))-Temp_Energy(paths(i,j));
                                Data(paths(i,j))=0;
                            elseif(paths(i,j)==0)
                                break;
                            end
                        end
                    end
                end
                Data(m)=0;
                Energy(m)=Energy(m)-Temp_Energy(m);
            end
        end
        Data=Data+dta;
        Total_data=Total_data+Nodes*dta;
        Energy=Energy+ener;
    end
    
    data_collect=data_collect+(t*Transmission_Rate);
    %
    %     disp("Network Size="+Nodes);
    %     disp("Total Data="+Total_data);
    %     disp("Data Collected="+data_collect);
    disp("Through="+(data_collect/Total_data));
    k=k+1;
    ap=ap+(data_collect/Total_data);
    disp(k);
end

disp("Avg Through="+ap/30);