a = 0;
b = 1;

for i=1:10
    c = a + b;
    disp(a);
    a = b;
    b = c;
end

a = 0;
b = 1;

while a<200
    c = a + b;
    disp(a);
    a = b;
    b = c;
end


