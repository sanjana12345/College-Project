
%% Initializing permanent variables
Nodes=100;  %number of sensors
x_coordinate=randi([0 200],1,Nodes); %x position of sensors
y_coordinate=randi([0 200],1,Nodes); %y position of sensors
Data=randi([1000 1000],1,Nodes); %data stored of sensors
Energy=randi([5 15],1,Nodes); %total energy of sensors
Radius=30; % Radius of communication
Graph=graph(); % Network of nodes
Adj=zeros(Nodes,Nodes); %Adjancey Matrix
Transmission_Rate= 10000; % Data Trasmission Rate
Speed = 2; % Mobile Sink Speed
Time=800;
ec=150*(10^-9);
eh=0.5*(10^-3); % Energy harvesting rate
dg=1000; % Data generation rate
data_collect=0;

%% Adding edges between nodes capable of communicating with each other or creating network
for i=1:Nodes
    for j=i+1:Nodes
        if (((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)<=Radius^2)
            line([x_coordinate(i) x_coordinate(j)],[y_coordinate(i) y_coordinate(j)],'Color','green');
            Graph=addedge(Graph,i,j);
            Adj(i,j)=1;
            Adj(j,i)=1;
        end
    end
end

sparseAdj=sparse(Adj);
Total_data= 1000 * Nodes;
%plot(Graph);
%hold on;

%% Finding Cluster heads and corresponding clusters.
loc=0;
loc_x=0;
loc_y=0;

%% Starting algorithm Finding Max Data/Time Location

%while(Time>0)
    max=0;
    disp("Time Left="+Time);
%     for i=1:Nodes
        Temp_Energy=Energy; %Temporary Energy Array
        visited=zeros(2,Nodes); %Visited Array. Row 1 contains visited boolean value
        paths=zeros(Nodes,Nodes); %Various Paths BFS.
        level_nodes=graphtraverse(sparseAdj,1,'depth',1);
        included=zeros(1,Nodes);
        sum_data=0;
        dist=sqrt((x_coordinate(i)-loc_x)^2+(y_coordinate(i)-loc_y)^2)/Speed;
        
        for nodes = level_nodes
            visited(1,nodes) = 1;
            visited(2,nodes) = nodes;
            sum_data=sum_data+Data(nodes);
            line([x_coordinate(1) x_coordinate(nodes)],[y_coordinate(1) y_coordinate(nodes)],'Color','red');
            hold on;
            included(nodes)=1;
        end

        x=1;
        for nodes = level_nodes
            current=nodes;
            if (current == i)
                continue;
            end
            alert=0;
            level=1;
            visited(2,current)=current;
            if(Temp_Energy(current)-(ec*Data(current))>=0)
                Temp_Energy(current)=Temp_Energy(current)-(ec*Data(current));
                while (alert==0)
                    [paths,visited,Temp_Energy,alert,x] = bfspaths(paths,visited,level,Temp_Energy,current,Graph,x,Data,sparseAdj,ec);
                    level=level+1;
                end
            end
        end
        
        for k=1:Nodes
            if(paths(k,1)==0)
                break;
            end
            for j=2:Nodes
                if(paths(k,j)~=0)
                    line([x_coordinate(paths(k,j-1)) x_coordinate(paths(k,j))],[y_coordinate(paths(k,j-1)) y_coordinate(paths(k,j))],'Color','blue');
                    hold on;
                elseif(paths(k,j)==0)
                    break;
                end
            end
        end
        
        %end
%end
%         for k=1:Nodes
%             if(paths(k,1)==0)
%                 break;
%             end
%             for j=2:Nodes
%                 if(paths(k,j)~=0 && included(paths(k,j))~=1)
%                     sum_data=sum_data+Data(paths(k,j));
%                     included(paths(k,j))=1;
%                 elseif(paths(k,j)==0)
%                     break;
%                 end
%             end
%         end
%         
%         sum_data=sum_data/dist;
%         if(i==loc)
%             sum_data=0;
%         end
%         if(sum_data>max)
%             max=sum_data;
%             loc=i;
%         end
%     end
%     
%     %% Calculating data,time and energy for choosen location
%     disp("loc="+loc);
%     Temp_Energy=Energy; %Temporary Energy Array
%     Temp_Data=Data; %Temporary Data Array
%     visited=zeros(2,Nodes); %Visited Array. Row 1 contains visited boolean value
%     paths=zeros(Nodes,Nodes); %Various Paths BFS.
%     level_nodes=graphtraverse(sparseAdj,loc,'depth',1);
%     included=zeros(1,Nodes);
%     sum_data=0;
%     dist=sqrt((x_coordinate(loc)-loc_x)^2 + (y_coordinate(loc)-loc_y)^2)/Speed;
%     for nodes = level_nodes
%         visited(1,nodes) = 1;
%         visited(2,nodes) = nodes;
%         sum_data=sum_data+Data(nodes);
%         included(nodes)=1;
%     end
%     x=1;
%     for nodes = level_nodes
%         current=nodes;
%         if (current == loc)
%             continue;
%         end
%         alert=0;
%         level=1;
%         visited(2,current)=current;
%         if(Temp_Energy(current)-(ec*Data(current))>=0)
%             Temp_Energy(current)=Temp_Energy(current)-(ec*Data(current));
%             while (alert==0)
%                 [paths,visited,Temp_Energy,alert,x] = bfspaths(paths,visited,level,Temp_Energy,current,Graph,x,Data,sparseAdj,ec);
%                 level=level+1;
%             end
%         end
%     end
%     
%     for k=1:Nodes
%         if(paths(k,1)==0)
%             break;
%         end
%         for j=2:Nodes
%             if(paths(k,j)~=0 && included(paths(k,j))~=1)
%                 sum_data=sum_data+Data(paths(k,j));
%                 included(paths(k,j))=1;
%                 Temp_Data(paths(k,1))=Temp_Data(paths(k,1))+Data(paths(k,j));
%                 Data(paths(k,j))=0;
%             elseif(paths(k,j)==0)
%                 break;
%             end
%         end
%     end
%     
%     max=0;
%     for nodes = level_nodes
%         Data(nodes)=0;
%         if(Temp_Data(nodes)>max)
%             max=Temp_Data(nodes);
%         end
%     end
%     
%     Temp_Energy(loc)=Temp_Energy(loc)-(ec*Temp_Data(loc));
%     Energy = Temp_Energy;
%     t=max/Transmission_Rate+dist;
%     Time=Time-t;
%     if(Time<0)
%         break;
%     end
%     harvest_energy=t*eh;
%     harvest_data=t*dg;
%     Total_data=Total_data+Nodes*harvest_data;
%     Data=Data+harvest_data;
%     Energy=Energy+harvest_energy;
%     data_collect=data_collect+sum_data;
%     loc_x=x_coordinate(loc);
%     loc_y=y_coordinate(loc);
% end
% disp(data_collect/Total_data);