function [node,x,paths,visited,Temp_Energy,k,alert] = find_next(node,Adj,paths,x,k,Nodes,Temp_Energy,Data,visited,alert,ec)
    iter=0;
    for m=1:Nodes
        flag=0;
        if (Adj(node,m) == 1 && visited(2,m)~=x && Temp_Energy(m)>0 && visited(3,m)~=1)
            for l=1:k-1
                if (Temp_Energy(paths(x,l))-(ec*Data(m))<0)
                    %Temp_Energy(paths(x,l))=Temp_Energy(paths(x,l))-Data(m);
                    %node = m;
                    break
                end
                flag=flag+1;
            end
            if(flag == k-1)
                flag = 1;
                node = m;
                for l=1:k-1
                        Temp_Energy(paths(x,l))=Temp_Energy(paths(x,l))-(ec*Data(m));
                end
            end    
        end
        if(flag==1)
            break;
        end
        iter=iter+1;
    end
    if(iter == Nodes && k>=3)
        x=x+1;
        for l=1:k-3
            paths(x,l)=paths(x-1,l);
            visited(2,paths(x,l))=x;
        end
        visited(3,node)=1;
        node = paths(x-1,k-2);
        k=k-2;
    elseif(iter == Nodes && k<3)
        alert=1;
        visited(3,node)=1;
    end    
end
    