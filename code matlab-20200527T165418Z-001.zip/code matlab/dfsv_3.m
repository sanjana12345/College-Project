lo=0;
ap=0;

while lo<30
    
    Nodes=100;  %number of sensors
    x_coordinate=randi([0 200],1,Nodes); %x position of sensors
    y_coordinate=randi([0 200],1,Nodes); %y position of sensors
    Data=randi([1000 1000],1,Nodes); %Initial data stored in sensors
    Energy=randi([5 15],1,Nodes); %Initial energy of sensors
    Radius=30; % Radius of communication
    Graph=graph(); % Network of nodes
    Adj=zeros(Nodes,Nodes); %Adjancey Matrix
    Distances=inf(Nodes,Nodes); %Distances between each node in terms of time taken for travelling
    Transmission_Rate= 10000; % Data Trasmission Rate
    Speed = 2; % Mobile Sink Speed
    Total_data = 1000*Nodes; % Total data offered by network
    t=800; % Time
    current_loc=1;
    eh=0.5*(10^-3); % Energy harvesting rate
    dg=1000; % Data generation rate
    ec=150*(10^-9); % Energy consumption per bit data
    data_collect=0; % Data collected
    
    % Adding edges between nodes capable of communicating with each other or creating network
    for i=1:Nodes
        for j=i+1:Nodes
            if (((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)<=Radius^2)
                Graph=addedge(Graph,i,j);
                Adj(i,j)=1;
                Adj(j,i)=1;
            end
            Distances(i,j)=sqrt((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)/Speed;
            Distances(j,i)=sqrt((x_coordinate(i)-x_coordinate(j))^2 + (y_coordinate(i)-y_coordinate(j))^2)/Speed;
        end
    end
    
    while(t>0)
        
        Cluster_head=zeros(1,Nodes); %If node is made a cluster head its hash is changed to 1.
        Temp_Energy=Energy; %Temporary Energy Array
        visited=zeros(3,Nodes); %Visited Array. Row 1 contains visited boolean value, Row 2 contains current path, Row 3 contains boolean dead end value
        paths=zeros(Nodes,Nodes); %Various Paths DFS.
        Ratio=Temp_Energy./Data; %Ratio of Energy Array by Data Array
        [Sorted_Ratio,Sorted_Ratio_Indices]=sort(Ratio,'descend'); %Returns sorted cluster parameter and their indices
        
        %Finding Cluster heads and corresponding clusters.
        x=1;
        for i=1:Nodes
            alert=0;
            k=1;
            node = Sorted_Ratio_Indices(i);
            while Temp_Energy(node)>=0 && visited(3,node)~=1
                paths(x,k) = node;
                if(visited(1,node)~=1)
                    Temp_Energy(node)=Temp_Energy(node)-(ec*Data(node));
                end
                k=k+1;
                visited(1,node)=1;
                visited(2,node)=x;
                [node,x,paths,visited,Temp_Energy,k,alert] = find_next(node,Adj,paths,x,k,Nodes,Temp_Energy,Data,visited,alert,ec);
                if(alert == 1)
                    break
                end
                if(k>Nodes)
                    for p=1:Nodes
                        paths(x,p)=0;
                    end
                    k=0;
                    break
                end
            end
        end
        
        %%[sum1]=find_sum(Cluster_head,Nodes);
        
        Temp_Data=Data;
        include=zeros(1,Nodes);
        rat=zeros(1,Nodes);
        
        for i=1:Nodes
            for j=2:Nodes
                if(paths(i,j)>0&&include(paths(i,j))==0)
                    Cluster_head(paths(i,j))=1;
                    Temp_Data(paths(i,1))=Temp_Data(paths(i,1))+Temp_Data(paths(i,j));
                    include(paths(i,j))=1;
                elseif(paths(i,j)==0)
                    break;
                end
            end
        end
        
        %% To calculate total data present at a cluster head with its cluster and neighbour.
        head_data=Temp_Data;
        
        for i=1:Nodes
            if(Cluster_head(i)==0)
                for j=1:Nodes
                    if(Cluster_head(j)==0&&Adj(i,j)==1)
                        head_data(i)=head_data(i)+Temp_Data(j);
                    end
                end
            end
        end
        
        for i=1:Nodes
            rat(i)=head_data(i)/Distances(current_loc,i);
        end
        
        
        [max_rat,max_rat_ind]=sort(rat,'descend');
        
        td=Distances(current_loc,max_rat_ind(1))+head_data(max_rat_ind(1))/Transmission_Rate;
        
        if(t-td<0)
            break;
        end
        t=t-td;
        data_collect=data_collect+head_data(max_rat_ind(1));
        dta=td*dg;
        ener=td*eh;
        
        include=zeros(1,Nodes);
        
        %% Deducting energy from cluster head and its neigbours
        for i=1:Nodes
            if(paths(i,1)==max_rat_ind(1))
                for j=2:Nodes
                    if(paths(i,j)>0)
                        Energy(paths(i,j))=Energy(paths(i,j))-Temp_Energy(paths(i,j));
                        Data(paths(i,j))=0;
                    elseif(paths(i,j)==0)
                        break;
                    end
                end
            end
        end
        Data(max_rat_ind(1))=0;
        Energy(max_rat_ind(1))=Energy(max_rat_ind(1))-Temp_Energy(max_rat_ind(1));
        
        for m=1:Nodes
            if(Cluster_head(m)==0 && Adj(m,max_rat_ind(1))==1)
                for i=1:Nodes
                    if(paths(i,1)==m)
                        for j=2:Nodes
                            if(paths(i,j)>0)
                                Energy(paths(i,j))=Energy(paths(i,j))-Temp_Energy(paths(i,j));
                                Data(paths(i,j))=0;
                            elseif(paths(i,j)==0)
                                break;
                            end
                        end
                    end
                end
                Data(m)=0;
                Energy(m)=Energy(m)-Temp_Energy(m);
            end
        end
        
        
        Data=Data+dta;
        Total_data=Total_data+Nodes*dta;
        Energy=Energy+ener;
        
    end
    
    data_collect=data_collect+(t*Transmission_Rate);
    %
    % disp("Network Size="+Nodes);
    % disp("Total Data="+Total_data);
    % disp("Data Collected="+data_collect);
    disp("Through="+(data_collect/Total_data));
    
    ap=ap+(data_collect/Total_data);
    lo=lo+1;
    disp(lo);
end

disp("Avg Through="+ap/30);
